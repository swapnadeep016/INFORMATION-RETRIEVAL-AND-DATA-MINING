# pip install python-twitter textblob matplotlib scikit-learn
# Code to fetch 100 tweet entries and a sample sentiment analysis depending on word counts
# Using count vectorizer and KNN classifer (neighbour size = 3)

# twitter request
import twitter

# word analysis
from textblob import TextBlob

# working for the developing the model
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import CountVectorizer, TfidfTransformer
from sklearn.metrics import confusion_matrix, classification_report,accuracy_score
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier

# for Graph
import matplotlib.pyplot as plt

# initialize api instance
twitter_api = twitter.Api(consumer_key='Rjg1xMgQcxjy8rZOEjbEJMInx',
                        consumer_secret='RAivsj2NCUgrfeqRA3GgY3XKvmBFSWGesNZJbs0QZep2La5s5R',
                        access_token_key='1255150330058178560-iuutYJew95XSdN5DuorDqIye7nWjGV',
                        access_token_secret='ZFhx4i8WsFmq9Io7503CJrj3kE7KIdCtE0tBVPelDWRYD')

def searchTerm(search_keyword):
    tweets_fetched = twitter_api.GetSearch(search_keyword, count = 100)     #Reading 100 text from twitter
    
    txt=[]         # list  declared to store the twitter text                                                            
    polarity =[]   # list  declared to store polarity in the text   (positivety in the text)
    subjectivity=[]    # list  declared to store subjectiveness in the text   (subjective or objective) 
    output=[]          # to generate a output decision depending on polarity and subjectivity
    
    # Reference Link https://planspace.org/20150607-textblob_sentiment/
    
    #   Creating sample the dataset

    i=0
    for status in tweets_fetched:
        analysis = TextBlob(status.text)      
        txt.append(status.text)
        polarity.append(analysis.sentiment[0])          # storing polarity
        subjectivity.append(analysis.sentiment[1])      # storing subjectivity
        if(polarity[i]>0 and subjectivity[i]>0.3): # condsidering an output where if polarity greater than 0 and subjectivity greater than 0.3 to be true  
            output.append(1)       # setting output 1 if true             
        else:
            output.append(0)       # setting output 0 if false
        i=i+1
    
    #ploting the subjectivity and polarity in a graph
    plt.plot(subjectivity)  
    plt.plot(polarity)
    plt.show()
    
    # Creating a pipeline to develop the model
    pipeline = Pipeline([
        ('bow',CountVectorizer()),  # strings to token integer counts
        ('tfidf', TfidfTransformer()),  # integer counts to weighted TF-IDF scores
        ('classifier',KNeighborsClassifier(n_neighbors=3)),  # KNeighboursClassifiers
    ])



    msg_train, msg_test, label_train, label_test = train_test_split(txt, output, test_size=0.2)   # Spliting the dataset 80 % training 20% testing
    pipeline.fit(msg_train,label_train)           # training the dataset
    predictions = pipeline.predict(msg_test)      # Testing the prediction
    
    # Printing predicted report value
    
    print(classification_report(predictions,label_test))        
    print(confusion_matrix(predictions,label_test))
    print(accuracy_score(predictions,label_test))

# calling the function with different keywords 

searchTerm("Covid 19")   
searchTerm("Ireland")
searchTerm( "Data Mining")
searchTerm( "Holiday")