#Yearwise Genre More Hits based on IMDB Rating
#importing the 3 different library for operations
import matplotlib.pyplot as plt 
import pandas as pd   
import numpy as np
data = pd.read_csv("blockbusters.csv")    # Reading the CSV file
data= data.head(30)   #Consider the top 30 values
fig, ax = plt.subplots(figsize=(15,7))      # plot size
data.groupby(['year','Main_Genre']).count()['imdb_rating'].plot(ax=ax,kind='bar')  #grouping based on year and Genre and counting defining the rank in the year to set the size in the bar chart
plt.show()# to display the plot


#Top 5 Films based on the Imbd Rating
#importing the 3 different library for operations
data = pd.read_csv("blockbusters.csv")  # Reading the CSV file
info = pd.DataFrame(data['imdb_rating'].sort_values(ascending = False))
info['title'] = data['title']
data = list(map(str,(info['title'])))
x = list(data[:5])
y = list(info['imdb_rating'][:5])
plt.scatter(x,y)   #creating a scatter plot
plt.plot(x,y)     #adding the line plot to it
plt.legend() 
plt.show()# to display the plot


#Pie Chart for based on Genre2 Top Films
#importing the 3 different library for operations
data = pd.read_csv("blockbusters.csv")  # Reading the CSV file
data= data.head(30)      #Consider the top 30 values
fig, ax = plt.subplots(figsize=(15,7))   # plot size
data.groupby(['year','Genre_2']).count()['rank_in_year'].plot(ax=ax,kind='pie')    #grouping based on year and Genre2 and counting defining the rank in the year to set the size in the pie chart
plt.show()   # to display the plot


#Rating Based Studio House
#importing the 3 different library for operations   
data = pd.read_csv("blockbusters.csv")  # Reading the CSV file
data= data.head(30)     #Consider the top 30 values 
fig, ax = plt.subplots(figsize=(15,7))    # plot size
data.groupby(['year','studio']).count()['imdb_rating'].plot(ax=ax,kind='bar')
plt.show()# to display the plot


#5th program
data = pd.read_csv("blockbusters.csv")  
data= data.head(50)
fig, ax = plt.subplots(figsize=(15,7))
data.groupby(['year','Main_Genre']).count()['worldwide_gross'].plot(ax=ax,kind='pie')
plt.show()